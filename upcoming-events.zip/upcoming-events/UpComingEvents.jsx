import React from "react";
import "./UpcomingEvents.css";
import { UpComingConstant } from "../../constant/UpComingConstant";
import { Pagination } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import { EventDetail } from "../../constant/constant";

const UpcomingEvents = () => {
  return (
    <div className="container-wrapper">
      {UpComingConstant.slice(0, 1).map((data, index) => {
        {
          console.log("data", data);
        }
        return (
          <div className="UpComing_Events" key={data.Event_Id}>
            <div className="greetings navSlider">
              <div className="greeting-heading">
                <div className="content-review">
                  <h1>{data.Event_title}</h1>
                  <div className="greetings-paragraph">
                    <p>{data.Event_Description}</p>
                  </div>
                </div>
                <div className="button-sections">
                  <button className="btn btn-black">{data.Event_button}</button>
                </div>
              </div>
            </div>

            {/* ---------content------- */}
            <div className="content-data">
              {UpComingConstant.slice(1, 2).map((event, index) => {
                return (
                  <div className="content">
                    <h1 className="content-heading">{event.Event_title}</h1>
                    <div className="review">
                      <p>
                        <span className="material-symbols-outlined stars">
                          grade
                        </span>
                        <span className="material-symbols-outlined stars">
                          grade
                        </span>
                        <span className="material-symbols-outlined stars">
                          grade
                        </span>
                        <span className="material-symbols-outlined stars">
                          grade
                        </span>
                        <span className="material-symbols-outlined stars">
                          grade
                        </span>
                      </p>
                      <p>
                        {event.Event_rating}

                        <strong>{event.Event_Location}</strong>
                      </p>
                    </div>
                  </div>
                );
              })}
              <div className="scheduled">
                <p>Scheduled</p>
              </div>
            </div>
            {/* -------------grid--------- */}
            <div className="grid-Scheduled">
              <div className="grid-container">
                <div className="div1">
                  <img src="./images/Image119.jpg" />
                </div>
                <div className="div2">
                  <img src="./images/Image119.jpg" />
                </div>
                <div className="div3">
                  <img src="./images/Image119.jpg" />
                </div>
                <div className="div4">
                  <img src="./images/Image119.jpg" />
                </div>
                <div className="div5">
                  <img src="./images/Image119.jpg" />
                  <div className="grid-button">
                    <button className="btn btn-show">Show all</button>
                  </div>
                </div>
              </div>
              <div className="Timeline">
                <div className="container">
                  <h2 className="time">10:30 AM - 7:30 PM</h2>
                </div>
                <div className="contents">
                  <div className="content-data">
                    <p className="content-left">
                      From <br />
                      Nov 10, 2022
                    </p>

                    <p className="content-right">
                      To
                      <br />
                      Nov 10, 2022
                    </p>
                  </div>
                  <hr />
                  <div className="guest-data">
                    <span className="guest">
                      Guests <br /> 1 adult
                    </span>
                  </div>
                </div>
              </div>
            </div>
            {/* ---------about- event---------- */}
            <div className="event-content">
              <h1 className="event-content-heading">About the event</h1>``
              <div className="information">
                <div className="game-data">
                  <p className="game">
                    <span className="material-symbols-outlined symbols">
                      view_cozy
                    </span>
                    Glof
                    <br />
                    This is one of the many events comes under the Golf
                    category.
                  </p>
                </div>
              </div>
              <div className="address-data">
                <p className="address">
                  <span className="material-symbols-outlined symbols">
                    location_on
                  </span>
                  Great location
                  <br />
                  Every guest has given a five star rating to this location
                </p>
              </div>
              <div className="overwhelmed-data">
                <div className="Overwhelmed">
                  <img src="./images/overwhelmed.svg" alt="" />
                  Invigorating & uplifting experienc
                  <br />
                  <p>
                    This event has a rating of 5.0 that make this event
                    overwhelmed.
                  </p>
                </div>
              </div>
              <div className="event-para">
                <p className="para">
                  Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                  diam nonumy eirmod tempor invidunt ut labore et dolore magna
                  aliquyam erat, sed diam voluptua. At vero eos et accusam et
                  justo duo dolores et ea rebum. Stet clita kasd gubergren, no
                  sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem
                  ipsum dolor sit amet, consetetur sadipscing elit. <br />
                  <br />
                  Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                  diam nonumy eirmod tempor invidunt ut labore et dolore magna
                  aliquyam erat, sed diam voluptua. At vero eos et accusam et
                  justo duo dolores et ea rebum. Stet clita kasd gubergren, no
                  sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem
                  ipsum dolor sit amet, consetetur sadipscing elit.
                </p>
              </div>
              {/* ----------event-operator------ */}
              <div className="event-operator">
                <h3 className=" events-content-heading">
                  Operator River Stone
                </h3>
                <div className="review">
                  <p>
                    <span className="material-symbols-outlined stars">
                      grade
                    </span>
                    <span className="material-symbols-outlined stars">
                      grade
                    </span>
                    <span className="material-symbols-outlined stars">
                      grade
                    </span>
                    <span className="material-symbols-outlined stars">
                      grade
                    </span>
                    <span className="material-symbols-outlined stars">
                      grade
                    </span>
                  </p>
                  <p>4.9</p>
                </div>
                <p className="event-para">
                  Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                  diam nonumy eirmod tempor invidunt ut labore et dolore magna
                  aliquyam erat, sed diam voluptua. At vero eos et accusam et
                  justo duo dolores et ea rebum. Stet clita kasd gubergren, no
                  sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem
                  ipsum dolor sit amet, consetetur sadipscing elit.
                </p>
              </div>
            </div>

            {/* --------SwiperSlide----- */}
            <Swiper
              slidesPerView={4}
              spaceBetween={3}
              pagination={{
                clickable: true,
              }}
              modules={[Pagination]}
              className="mySwiper"
            >
              <div className="slide-container  ">
                {UpComingConstant.map((data, item) => {
                  return (
                    <SwiperSlide
                      className="slide-content swiper-slide"
                      key={data.Event_Id}
                    >
                      <div className="card-wrapper ">
                        <div className="card ">
                          <div className="image-content">
                            <div className="card-image">
                              <img
                                src="./images/user1.png"
                                className="card-img"
                              />
                            </div>

                            <div className="card-content">
                              <h2 className="name">{data.Event_name}</h2>
                              <span className="date">{data.Event_date}</span>
                            </div>
                          </div>
                          <div className="description">
                            <p>{data.Event_Description}</p>
                            <div className="review">
                              <p>
                                <span className="material-symbols-outlined stars">
                                  grade
                                </span>
                                <span className="material-symbols-outlined stars">
                                  grade
                                </span>
                                <span className="material-symbols-outlined stars">
                                  grade
                                </span>
                                <span className="material-symbols-outlined stars">
                                  grade
                                </span>
                                <span className="material-symbols-outlined stars">
                                  grade
                                </span>
                                4.9
                              </p>
                            </div>
                            <p className="slider-content-content">
                              <a href="" className="read-content">
                                Read more
                              </a>
                            </p>
                          </div>
                        </div>
                      </div>
                    </SwiperSlide>
                  );
                })}

                <SwiperSlide className="slide-content swiper-slide">
                  <div className="card-wrapper ">
                    <div className="card ">
                      <div className="image-content">
                        <span className="overlay"></span>
                        <div className="card-image">
                          <img src="./images/user2.png" className="card-img" />
                        </div>

                        <div className="card-content">
                          <h2 className="name">Anastasia</h2>
                          <span className="date">Nov 2022</span>
                        </div>
                      </div>
                      <div className="description">
                        <p>
                          Lorem ipsum dolor sit amet, consetetur sadipscing
                          elitr, sed diam nonumy eirmod tempor invidunt ut
                          labore et dolore magna aliquyam erat, sed diam
                          voluptua. At vero eos et accusam et justo...
                        </p>
                        <div className="review">
                          <p>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            4.9
                          </p>
                        </div>
                        <p className="slider-content-content">
                          <a href="" className="read-content">
                            Read more
                          </a>
                        </p>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="slide-content swiper-slide">
                  <div className="card-wrapper ">
                    <div className="card ">
                      <div className="image-content">
                        <span className="overlay"></span>
                        <div className="card-image">
                          <img src="./images/user3.png" className="card-img" />
                        </div>

                        <div className="card-content">
                          <h2 className="name">Anastasia</h2>
                          <span className="date">Nov 2022</span>
                        </div>
                      </div>
                      <div className="description">
                        <p>
                          Lorem ipsum dolor sit amet, consetetur sadipscing
                          elitr, sed diam nonumy eirmod tempor invidunt ut
                          labore et dolore magna aliquyam erat, sed diam
                          voluptua. At vero eos et accusam et justo...
                        </p>
                        <div className="review">
                          <p>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            4.9
                          </p>
                        </div>
                        <p className="slider-content-content">
                          <a href="" className="read-content">
                            Read more
                          </a>
                        </p>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="slide-content swiper-slide">
                  <div className="card-wrapper ">
                    <div className="card ">
                      <div className="image-content">
                        <span className="overlay"></span>
                        <div className="card-image">
                          <img src="./images/user4.png" className="card-img" />
                        </div>

                        <div className="card-content">
                          <h2 className="name">Anastasia</h2>
                          <span className="date">Nov 2022</span>
                        </div>
                      </div>
                      <div className="description">
                        <p>
                          Lorem ipsum dolor sit amet, consetetur sadipscing
                          elitr, sed diam nonumy eirmod tempor invidunt ut
                          labore et dolore magna aliquyam erat, sed diam
                          voluptua. At vero eos et accusam et justo...
                        </p>
                        <div className="review">
                          <p>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            4.9
                          </p>
                        </div>
                        <p className="slider-content-content">
                          <a href="" className="read-content">
                            Read more
                          </a>
                        </p>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="slide-content swiper-slide">
                  <div className="card-wrapper ">
                    <div className="card ">
                      <div className="image-content">
                        <span className="overlay"></span>
                        <div className="card-image">
                          <img src="./images/user4.png" className="card-img" />
                        </div>

                        <div className="card-content">
                          <h2 className="name">Anastasia</h2>
                          <span className="date">Nov 2022</span>
                        </div>
                      </div>
                      <div className="description">
                        <p>
                          Lorem ipsum dolor sit amet, consetetur sadipscing
                          elitr, sed diam nonumy eirmod tempor invidunt ut
                          labore et dolore magna aliquyam erat, sed diam
                          voluptua. At vero eos et accusam et justo...
                        </p>
                        <div className="review">
                          <p>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            <span className="material-symbols-outlined stars">
                              grade
                            </span>
                            4.9
                          </p>
                        </div>
                        <p className="slider-content-content">
                          <a href="" className="read-content">
                            Read more
                          </a>
                        </p>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              </div>
            </Swiper>
            {/* ---------------Events-------- */}
            <div className="today-recommendations-1">
              <div className="container-recommendation  navSlider">
                <h2 className="today-title">
                  Some more recommendations for you, Charlie!
                </h2>
                <div className="today-recommendation-imageContainer">
                  {EventDetail.map((item, index) => {
                    console.log("item", item);
                    return (
                      <div
                        className="today-recommendation-imageCard"
                        key={item.Event_ID}
                      >
                        <div className="today-recommendation-mainImage">
                          <img src={item.url} alt="pic" />
                        </div>
                        <div className="today-recommendations-imageCard-content">
                          <span className="Overwhelmed">
                            <img src="./images/overwhelmed.svg" alt="" />
                            <p>Invigorating & Uplifting</p>
                          </span>
                          <span>{item.Event_Start_Date}</span>
                        </div>
                        <div className="today-recommendation-imageCard-mainContent">
                          <h4 className="today-recommendation-imageCard-mainContent-title">
                            {item.Event_Name}
                          </h4>
                          <p>{item.Event_End_Date}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* ---------Events2-------- */}
            <div className="today-recommendations-1">
              <div className="container-recommendation  navSlider">
                <div className="today-recommendation-imageContainer">
                  {EventDetail.map((item, index) => {
                    console.log("item", item);
                    return (
                      <div className="today-recommendation-imageCard">
                        <div className="today-recommendation-mainImage">
                          <img src={item.url} alt="pic" />
                        </div>
                        <div className="today-recommendations-imageCard-content">
                          <span className="Overwhelmed">
                            <img src="./images/overwhelmed.svg" alt="" />
                            <p>Invigorating & Uplifting</p>
                          </span>
                          <span>{item.Event_Start_Date}</span>
                        </div>
                        <div className="today-recommendation-imageCard-mainContent">
                          <h4 className="today-recommendation-imageCard-mainContent-title">
                            {item.Event_Name}
                          </h4>
                          <p>{item.Event_End_Date}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default UpcomingEvents;
